import * as wasm from "./d2_calculation_api_bg.wasm";
export * from "./d2_calculation_api_bg.js";
wasm.__wbindgen_start();
