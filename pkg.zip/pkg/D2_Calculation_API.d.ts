/* tslint:disable */
/* eslint-disable */
/**
*/
export function start(): void;
/**
* @returns {boolean}
*/
export function isWeaponInitialized(): boolean;
/**
* @returns {number}
*/
export function getWeaponId(): number;
/**
* @param {number} _stat
* @returns {Stat}
*/
export function getStat(_stat: number): Stat;
/**
* @param {number} perk_hash
* @returns {boolean}
*/
export function isPerkImplemented(perk_hash: number): boolean;
/**
* @returns {Uint32Array}
*/
export function queryPerks(): Uint32Array;
/**
* @param {number} perk_hash
* @param {number} new_value
*/
export function changePerkValue(perk_hash: number, new_value: number): void;
/**
*/
export class AmmoData {
  free(): void;
/**
*/
  is_primary: boolean;
/**
*/
  mag_evpp: number;
/**
*/
  mag_offset: number;
/**
*/
  mag_round_to_nearest: number;
/**
*/
  mag_vpp: number;
/**
*/
  reserve_id: number;
}
/**
*/
export class AmmoResponse {
  free(): void;
/**
*/
  mag_size: number;
/**
*/
  reserve_size: number;
}
/**
*/
export class DamageModifiers {
  free(): void;
/**
*/
  boss: number;
/**
*/
  champion: number;
/**
*/
  elite: number;
/**
*/
  global: number;
/**
*/
  miniboss: number;
/**
*/
  minor: number;
/**
*/
  vehicle: number;
}
/**
*/
export class DpsResponse {
  free(): void;
/**
*/
  total_damage: number;
/**
*/
  total_shots: number;
/**
*/
  total_time: number;
}
/**
*/
export class FiringData {
  free(): void;
/**
*/
  burst_delay: number;
/**
*/
  burst_duration: number;
/**
*/
  burst_size: number;
/**
*/
  crit_mult: number;
/**
*/
  damage: number;
/**
*/
  is_charge: boolean;
/**
*/
  is_explosive: boolean;
/**
*/
  one_ammo_burst: boolean;
}
/**
*/
export class HandlingFormula {
  free(): void;
/**
*/
  ads_offset: number;
/**
*/
  ads_vpp: number;
/**
*/
  ready_offset: number;
/**
*/
  ready_vpp: number;
/**
*/
  stow_offset: number;
/**
*/
  stow_vpp: number;
}
/**
*/
export class HandlingResponse {
  free(): void;
/**
*/
  ads_time: number;
/**
*/
  ready_time: number;
/**
*/
  stow_time: number;
}
/**
*/
export class Perk {
  free(): void;
/**
*/
  enhanced: boolean;
/**
*/
  id: number;
/**
*/
  value: number;
}
/**
*/
export class RangeFormula {
  free(): void;
/**
*/
  floor_percent: number;
/**
*/
  is_fusion: boolean;
/**
*/
  offset_end: number;
/**
*/
  offset_start: number;
/**
*/
  vpp_end: number;
/**
*/
  vpp_start: number;
}
/**
*/
export class RangeResponse {
  free(): void;
/**
*/
  ads_falloff_end: number;
/**
*/
  ads_falloff_start: number;
/**
*/
  floor_percent: number;
/**
*/
  hip_falloff_end: number;
/**
*/
  hip_falloff_start: number;
}
/**
*/
export class ReloadFormula {
  free(): void;
/**
*/
  ammo_percent: number;
/**
*/
  evpp: number;
/**
*/
  offset: number;
/**
*/
  vpp: number;
}
/**
*/
export class ReloadResponse {
  free(): void;
/**
*/
  ammo_time: number;
/**
*/
  reload_time: number;
}
/**
*/
export class Stat {
  free(): void;
/**
*/
  base_value: number;
/**
*/
  part_value: number;
/**
*/
  perk_value: number;
}
/**
*/
export class TtkResponse {
  free(): void;
/**
*/
  ammo_needed: number;
/**
*/
  bodyshot_ttk: number;
/**
*/
  crit_percent: number;
/**
*/
  hits_needed: number;
/**
*/
  optimal_ttk: number;
}
/**
*/
export class Weapon {
  free(): void;
/**
*/
  ammo_type: number;
/**
*/
  damage_modifiers: DamageModifiers;
/**
*/
  damage_type: number;
/**
*/
  formulas: WeaponFormula;
/**
*/
  hash: number;
/**
*/
  weapon_slot: number;
/**
*/
  weapon_type: number;
}
/**
*/
export class WeaponFormula {
  free(): void;
/**
*/
  ammo_data: AmmoData;
/**
*/
  firing_data: FiringData;
/**
*/
  handling_data: HandlingFormula;
/**
*/
  range_data: RangeFormula;
/**
*/
  reload_data: ReloadFormula;
}
