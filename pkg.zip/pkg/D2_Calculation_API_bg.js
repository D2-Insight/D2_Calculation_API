import * as wasm from './d2_calculation_api_bg.wasm';

const heap = new Array(32).fill(undefined);

heap.push(undefined, null, true, false);

function getObject(idx) { return heap[idx]; }

let heap_next = heap.length;

function dropObject(idx) {
    if (idx < 36) return;
    heap[idx] = heap_next;
    heap_next = idx;
}

function takeObject(idx) {
    const ret = getObject(idx);
    dropObject(idx);
    return ret;
}

function addHeapObject(obj) {
    if (heap_next === heap.length) heap.push(heap.length + 1);
    const idx = heap_next;
    heap_next = heap[idx];

    heap[idx] = obj;
    return idx;
}

function debugString(val) {
    // primitive types
    const type = typeof val;
    if (type == 'number' || type == 'boolean' || val == null) {
        return  `${val}`;
    }
    if (type == 'string') {
        return `"${val}"`;
    }
    if (type == 'symbol') {
        const description = val.description;
        if (description == null) {
            return 'Symbol';
        } else {
            return `Symbol(${description})`;
        }
    }
    if (type == 'function') {
        const name = val.name;
        if (typeof name == 'string' && name.length > 0) {
            return `Function(${name})`;
        } else {
            return 'Function';
        }
    }
    // objects
    if (Array.isArray(val)) {
        const length = val.length;
        let debug = '[';
        if (length > 0) {
            debug += debugString(val[0]);
        }
        for(let i = 1; i < length; i++) {
            debug += ', ' + debugString(val[i]);
        }
        debug += ']';
        return debug;
    }
    // Test for built-in
    const builtInMatches = /\[object ([^\]]+)\]/.exec(toString.call(val));
    let className;
    if (builtInMatches.length > 1) {
        className = builtInMatches[1];
    } else {
        // Failed to match the standard '[object ClassName]'
        return toString.call(val);
    }
    if (className == 'Object') {
        // we're a user defined class or Object
        // JSON.stringify avoids problems with cycles, and is generally much
        // easier than looping through ownProperties of `val`.
        try {
            return 'Object(' + JSON.stringify(val) + ')';
        } catch (_) {
            return 'Object';
        }
    }
    // errors
    if (val instanceof Error) {
        return `${val.name}: ${val.message}\n${val.stack}`;
    }
    // TODO we could test for more things here, like `Set`s and `Map`s.
    return className;
}

let WASM_VECTOR_LEN = 0;

let cachedUint8Memory0 = new Uint8Array();

function getUint8Memory0() {
    if (cachedUint8Memory0.byteLength === 0) {
        cachedUint8Memory0 = new Uint8Array(wasm.memory.buffer);
    }
    return cachedUint8Memory0;
}

const lTextEncoder = typeof TextEncoder === 'undefined' ? (0, module.require)('util').TextEncoder : TextEncoder;

let cachedTextEncoder = new lTextEncoder('utf-8');

const encodeString = (typeof cachedTextEncoder.encodeInto === 'function'
    ? function (arg, view) {
    return cachedTextEncoder.encodeInto(arg, view);
}
    : function (arg, view) {
    const buf = cachedTextEncoder.encode(arg);
    view.set(buf);
    return {
        read: arg.length,
        written: buf.length
    };
});

function passStringToWasm0(arg, malloc, realloc) {

    if (realloc === undefined) {
        const buf = cachedTextEncoder.encode(arg);
        const ptr = malloc(buf.length);
        getUint8Memory0().subarray(ptr, ptr + buf.length).set(buf);
        WASM_VECTOR_LEN = buf.length;
        return ptr;
    }

    let len = arg.length;
    let ptr = malloc(len);

    const mem = getUint8Memory0();

    let offset = 0;

    for (; offset < len; offset++) {
        const code = arg.charCodeAt(offset);
        if (code > 0x7F) break;
        mem[ptr + offset] = code;
    }

    if (offset !== len) {
        if (offset !== 0) {
            arg = arg.slice(offset);
        }
        ptr = realloc(ptr, len, len = offset + arg.length * 3);
        const view = getUint8Memory0().subarray(ptr + offset, ptr + len);
        const ret = encodeString(arg, view);

        offset += ret.written;
    }

    WASM_VECTOR_LEN = offset;
    return ptr;
}

let cachedInt32Memory0 = new Int32Array();

function getInt32Memory0() {
    if (cachedInt32Memory0.byteLength === 0) {
        cachedInt32Memory0 = new Int32Array(wasm.memory.buffer);
    }
    return cachedInt32Memory0;
}

const lTextDecoder = typeof TextDecoder === 'undefined' ? (0, module.require)('util').TextDecoder : TextDecoder;

let cachedTextDecoder = new lTextDecoder('utf-8', { ignoreBOM: true, fatal: true });

cachedTextDecoder.decode();

function getStringFromWasm0(ptr, len) {
    return cachedTextDecoder.decode(getUint8Memory0().subarray(ptr, ptr + len));
}

function _assertClass(instance, klass) {
    if (!(instance instanceof klass)) {
        throw new Error(`expected instance of ${klass.name}`);
    }
    return instance.ptr;
}

let cachedUint32Memory0 = new Uint32Array();

function getUint32Memory0() {
    if (cachedUint32Memory0.byteLength === 0) {
        cachedUint32Memory0 = new Uint32Array(wasm.memory.buffer);
    }
    return cachedUint32Memory0;
}

function passArrayJsValueToWasm0(array, malloc) {
    const ptr = malloc(array.length * 4);
    const mem = getUint32Memory0();
    for (let i = 0; i < array.length; i++) {
        mem[ptr / 4 + i] = addHeapObject(array[i]);
    }
    WASM_VECTOR_LEN = array.length;
    return ptr;
}

function getArrayJsValueFromWasm0(ptr, len) {
    const mem = getUint32Memory0();
    const slice = mem.subarray(ptr / 4, ptr / 4 + len);
    const result = [];
    for (let i = 0; i < slice.length; i++) {
        result.push(takeObject(slice[i]));
    }
    return result;
}

let cachedFloat64Memory0 = new Float64Array();

function getFloat64Memory0() {
    if (cachedFloat64Memory0.byteLength === 0) {
        cachedFloat64Memory0 = new Float64Array(wasm.memory.buffer);
    }
    return cachedFloat64Memory0;
}

function getArrayF64FromWasm0(ptr, len) {
    return getFloat64Memory0().subarray(ptr / 8, ptr / 8 + len);
}
/**
*/
export function start() {
    wasm.start();
}

/**
* @returns {boolean}
*/
export function isWeaponInitialized() {
    const ret = wasm.isWeaponInitialized();
    return ret !== 0;
}

/**
* @returns {number}
*/
export function getWeaponId() {
    const ret = wasm.getWeaponId();
    return ret >>> 0;
}

/**
* @param {number} _stat
* @returns {Stat}
*/
export function getStat(_stat) {
    const ret = wasm.getStat(_stat);
    return Stat.__wrap(ret);
}

/**
* @param {number} perk_hash
* @returns {boolean}
*/
export function isPerkImplemented(perk_hash) {
    const ret = wasm.isPerkImplemented(perk_hash);
    return ret !== 0;
}

function getArrayU32FromWasm0(ptr, len) {
    return getUint32Memory0().subarray(ptr / 4, ptr / 4 + len);
}
/**
* @returns {Uint32Array}
*/
export function queryPerks() {
    try {
        const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
        wasm.queryPerks(retptr);
        var r0 = getInt32Memory0()[retptr / 4 + 0];
        var r1 = getInt32Memory0()[retptr / 4 + 1];
        var v0 = getArrayU32FromWasm0(r0, r1).slice();
        wasm.__wbindgen_free(r0, r1 * 4);
        return v0;
    } finally {
        wasm.__wbindgen_add_to_stack_pointer(16);
    }
}

/**
* @param {number} perk_hash
* @param {number} new_value
*/
export function changePerkValue(perk_hash, new_value) {
    wasm.changePerkValue(perk_hash, new_value);
}

/**
*/
export class AmmoData {

    static __wrap(ptr) {
        const obj = Object.create(AmmoData.prototype);
        obj.ptr = ptr;

        return obj;
    }

    __destroy_into_raw() {
        const ptr = this.ptr;
        this.ptr = 0;

        return ptr;
    }

    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_ammodata_free(ptr);
    }
    /**
    * @returns {number}
    */
    get mag_evpp() {
        const ret = wasm.__wbg_get_ammodata_mag_evpp(this.ptr);
        return ret;
    }
    /**
    * @param {number} arg0
    */
    set mag_evpp(arg0) {
        wasm.__wbg_set_ammodata_mag_evpp(this.ptr, arg0);
    }
    /**
    * @returns {number}
    */
    get mag_vpp() {
        const ret = wasm.__wbg_get_ammodata_mag_vpp(this.ptr);
        return ret;
    }
    /**
    * @param {number} arg0
    */
    set mag_vpp(arg0) {
        wasm.__wbg_set_ammodata_mag_vpp(this.ptr, arg0);
    }
    /**
    * @returns {number}
    */
    get mag_offset() {
        const ret = wasm.__wbg_get_ammodata_mag_offset(this.ptr);
        return ret;
    }
    /**
    * @param {number} arg0
    */
    set mag_offset(arg0) {
        wasm.__wbg_set_ammodata_mag_offset(this.ptr, arg0);
    }
    /**
    * @returns {number}
    */
    get mag_round_to_nearest() {
        const ret = wasm.__wbg_get_ammodata_mag_round_to_nearest(this.ptr);
        return ret;
    }
    /**
    * @param {number} arg0
    */
    set mag_round_to_nearest(arg0) {
        wasm.__wbg_set_ammodata_mag_round_to_nearest(this.ptr, arg0);
    }
    /**
    * @returns {boolean}
    */
    get is_primary() {
        const ret = wasm.__wbg_get_ammodata_is_primary(this.ptr);
        return ret !== 0;
    }
    /**
    * @param {boolean} arg0
    */
    set is_primary(arg0) {
        wasm.__wbg_set_ammodata_is_primary(this.ptr, arg0);
    }
    /**
    * @returns {number}
    */
    get reserve_id() {
        const ret = wasm.__wbg_get_ammodata_reserve_id(this.ptr);
        return ret;
    }
    /**
    * @param {number} arg0
    */
    set reserve_id(arg0) {
        wasm.__wbg_set_ammodata_reserve_id(this.ptr, arg0);
    }
}
/**
*/
export class AmmoResponse {

    __destroy_into_raw() {
        const ptr = this.ptr;
        this.ptr = 0;

        return ptr;
    }

    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_ammoresponse_free(ptr);
    }
    /**
    * @returns {number}
    */
    get mag_size() {
        const ret = wasm.__wbg_get_ammoresponse_mag_size(this.ptr);
        return ret;
    }
    /**
    * @param {number} arg0
    */
    set mag_size(arg0) {
        wasm.__wbg_set_ammoresponse_mag_size(this.ptr, arg0);
    }
    /**
    * @returns {number}
    */
    get reserve_size() {
        const ret = wasm.__wbg_get_ammoresponse_reserve_size(this.ptr);
        return ret;
    }
    /**
    * @param {number} arg0
    */
    set reserve_size(arg0) {
        wasm.__wbg_set_ammoresponse_reserve_size(this.ptr, arg0);
    }
}
/**
*/
export class DamageModifiers {

    static __wrap(ptr) {
        const obj = Object.create(DamageModifiers.prototype);
        obj.ptr = ptr;

        return obj;
    }

    __destroy_into_raw() {
        const ptr = this.ptr;
        this.ptr = 0;

        return ptr;
    }

    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_damagemodifiers_free(ptr);
    }
    /**
    * @returns {number}
    */
    get global() {
        const ret = wasm.__wbg_get_ammodata_mag_evpp(this.ptr);
        return ret;
    }
    /**
    * @param {number} arg0
    */
    set global(arg0) {
        wasm.__wbg_set_ammodata_mag_evpp(this.ptr, arg0);
    }
    /**
    * @returns {number}
    */
    get vehicle() {
        const ret = wasm.__wbg_get_ammodata_mag_vpp(this.ptr);
        return ret;
    }
    /**
    * @param {number} arg0
    */
    set vehicle(arg0) {
        wasm.__wbg_set_ammodata_mag_vpp(this.ptr, arg0);
    }
    /**
    * @returns {number}
    */
    get boss() {
        const ret = wasm.__wbg_get_ammodata_mag_offset(this.ptr);
        return ret;
    }
    /**
    * @param {number} arg0
    */
    set boss(arg0) {
        wasm.__wbg_set_ammodata_mag_offset(this.ptr, arg0);
    }
    /**
    * @returns {number}
    */
    get miniboss() {
        const ret = wasm.__wbg_get_damagemodifiers_miniboss(this.ptr);
        return ret;
    }
    /**
    * @param {number} arg0
    */
    set miniboss(arg0) {
        wasm.__wbg_set_damagemodifiers_miniboss(this.ptr, arg0);
    }
    /**
    * @returns {number}
    */
    get champion() {
        const ret = wasm.__wbg_get_damagemodifiers_champion(this.ptr);
        return ret;
    }
    /**
    * @param {number} arg0
    */
    set champion(arg0) {
        wasm.__wbg_set_damagemodifiers_champion(this.ptr, arg0);
    }
    /**
    * @returns {number}
    */
    get elite() {
        const ret = wasm.__wbg_get_damagemodifiers_elite(this.ptr);
        return ret;
    }
    /**
    * @param {number} arg0
    */
    set elite(arg0) {
        wasm.__wbg_set_damagemodifiers_elite(this.ptr, arg0);
    }
    /**
    * @returns {number}
    */
    get minor() {
        const ret = wasm.__wbg_get_damagemodifiers_minor(this.ptr);
        return ret;
    }
    /**
    * @param {number} arg0
    */
    set minor(arg0) {
        wasm.__wbg_set_damagemodifiers_minor(this.ptr, arg0);
    }
}
/**
*/
export class DpsResponse {

    __destroy_into_raw() {
        const ptr = this.ptr;
        this.ptr = 0;

        return ptr;
    }

    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_dpsresponse_free(ptr);
    }
    /**
    * @returns {number}
    */
    get total_damage() {
        const ret = wasm.__wbg_get_ammodata_mag_evpp(this.ptr);
        return ret;
    }
    /**
    * @param {number} arg0
    */
    set total_damage(arg0) {
        wasm.__wbg_set_ammodata_mag_evpp(this.ptr, arg0);
    }
    /**
    * @returns {number}
    */
    get total_time() {
        const ret = wasm.__wbg_get_ammodata_mag_vpp(this.ptr);
        return ret;
    }
    /**
    * @param {number} arg0
    */
    set total_time(arg0) {
        wasm.__wbg_set_ammodata_mag_vpp(this.ptr, arg0);
    }
    /**
    * @returns {number}
    */
    get total_shots() {
        const ret = wasm.__wbg_get_dpsresponse_total_shots(this.ptr);
        return ret;
    }
    /**
    * @param {number} arg0
    */
    set total_shots(arg0) {
        wasm.__wbg_set_dpsresponse_total_shots(this.ptr, arg0);
    }
}
/**
*/
export class FiringData {

    static __wrap(ptr) {
        const obj = Object.create(FiringData.prototype);
        obj.ptr = ptr;

        return obj;
    }

    __destroy_into_raw() {
        const ptr = this.ptr;
        this.ptr = 0;

        return ptr;
    }

    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_firingdata_free(ptr);
    }
    /**
    * @returns {number}
    */
    get damage() {
        const ret = wasm.__wbg_get_ammodata_mag_evpp(this.ptr);
        return ret;
    }
    /**
    * @param {number} arg0
    */
    set damage(arg0) {
        wasm.__wbg_set_ammodata_mag_evpp(this.ptr, arg0);
    }
    /**
    * @returns {number}
    */
    get crit_mult() {
        const ret = wasm.__wbg_get_ammodata_mag_vpp(this.ptr);
        return ret;
    }
    /**
    * @param {number} arg0
    */
    set crit_mult(arg0) {
        wasm.__wbg_set_ammodata_mag_vpp(this.ptr, arg0);
    }
    /**
    * @returns {number}
    */
    get burst_delay() {
        const ret = wasm.__wbg_get_ammodata_mag_offset(this.ptr);
        return ret;
    }
    /**
    * @param {number} arg0
    */
    set burst_delay(arg0) {
        wasm.__wbg_set_ammodata_mag_offset(this.ptr, arg0);
    }
    /**
    * @returns {number}
    */
    get burst_duration() {
        const ret = wasm.__wbg_get_damagemodifiers_miniboss(this.ptr);
        return ret;
    }
    /**
    * @param {number} arg0
    */
    set burst_duration(arg0) {
        wasm.__wbg_set_damagemodifiers_miniboss(this.ptr, arg0);
    }
    /**
    * @returns {number}
    */
    get burst_size() {
        const ret = wasm.__wbg_get_firingdata_burst_size(this.ptr);
        return ret;
    }
    /**
    * @param {number} arg0
    */
    set burst_size(arg0) {
        wasm.__wbg_set_firingdata_burst_size(this.ptr, arg0);
    }
    /**
    * @returns {boolean}
    */
    get one_ammo_burst() {
        const ret = wasm.__wbg_get_firingdata_one_ammo_burst(this.ptr);
        return ret !== 0;
    }
    /**
    * @param {boolean} arg0
    */
    set one_ammo_burst(arg0) {
        wasm.__wbg_set_firingdata_one_ammo_burst(this.ptr, arg0);
    }
    /**
    * @returns {boolean}
    */
    get is_charge() {
        const ret = wasm.__wbg_get_firingdata_is_charge(this.ptr);
        return ret !== 0;
    }
    /**
    * @param {boolean} arg0
    */
    set is_charge(arg0) {
        wasm.__wbg_set_firingdata_is_charge(this.ptr, arg0);
    }
    /**
    * @returns {boolean}
    */
    get is_explosive() {
        const ret = wasm.__wbg_get_firingdata_is_explosive(this.ptr);
        return ret !== 0;
    }
    /**
    * @param {boolean} arg0
    */
    set is_explosive(arg0) {
        wasm.__wbg_set_firingdata_is_explosive(this.ptr, arg0);
    }
}
/**
*/
export class HandlingFormula {

    static __wrap(ptr) {
        const obj = Object.create(HandlingFormula.prototype);
        obj.ptr = ptr;

        return obj;
    }

    __destroy_into_raw() {
        const ptr = this.ptr;
        this.ptr = 0;

        return ptr;
    }

    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_handlingformula_free(ptr);
    }
    /**
    * @returns {number}
    */
    get ready_vpp() {
        const ret = wasm.__wbg_get_ammodata_mag_evpp(this.ptr);
        return ret;
    }
    /**
    * @param {number} arg0
    */
    set ready_vpp(arg0) {
        wasm.__wbg_set_ammodata_mag_evpp(this.ptr, arg0);
    }
    /**
    * @returns {number}
    */
    get ready_offset() {
        const ret = wasm.__wbg_get_ammodata_mag_vpp(this.ptr);
        return ret;
    }
    /**
    * @param {number} arg0
    */
    set ready_offset(arg0) {
        wasm.__wbg_set_ammodata_mag_vpp(this.ptr, arg0);
    }
    /**
    * @returns {number}
    */
    get stow_vpp() {
        const ret = wasm.__wbg_get_ammodata_mag_offset(this.ptr);
        return ret;
    }
    /**
    * @param {number} arg0
    */
    set stow_vpp(arg0) {
        wasm.__wbg_set_ammodata_mag_offset(this.ptr, arg0);
    }
    /**
    * @returns {number}
    */
    get stow_offset() {
        const ret = wasm.__wbg_get_damagemodifiers_miniboss(this.ptr);
        return ret;
    }
    /**
    * @param {number} arg0
    */
    set stow_offset(arg0) {
        wasm.__wbg_set_damagemodifiers_miniboss(this.ptr, arg0);
    }
    /**
    * @returns {number}
    */
    get ads_vpp() {
        const ret = wasm.__wbg_get_damagemodifiers_champion(this.ptr);
        return ret;
    }
    /**
    * @param {number} arg0
    */
    set ads_vpp(arg0) {
        wasm.__wbg_set_damagemodifiers_champion(this.ptr, arg0);
    }
    /**
    * @returns {number}
    */
    get ads_offset() {
        const ret = wasm.__wbg_get_damagemodifiers_elite(this.ptr);
        return ret;
    }
    /**
    * @param {number} arg0
    */
    set ads_offset(arg0) {
        wasm.__wbg_set_damagemodifiers_elite(this.ptr, arg0);
    }
}
/**
*/
export class HandlingResponse {

    __destroy_into_raw() {
        const ptr = this.ptr;
        this.ptr = 0;

        return ptr;
    }

    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_handlingresponse_free(ptr);
    }
    /**
    * @returns {number}
    */
    get ready_time() {
        const ret = wasm.__wbg_get_ammodata_mag_evpp(this.ptr);
        return ret;
    }
    /**
    * @param {number} arg0
    */
    set ready_time(arg0) {
        wasm.__wbg_set_ammodata_mag_evpp(this.ptr, arg0);
    }
    /**
    * @returns {number}
    */
    get stow_time() {
        const ret = wasm.__wbg_get_ammodata_mag_vpp(this.ptr);
        return ret;
    }
    /**
    * @param {number} arg0
    */
    set stow_time(arg0) {
        wasm.__wbg_set_ammodata_mag_vpp(this.ptr, arg0);
    }
    /**
    * @returns {number}
    */
    get ads_time() {
        const ret = wasm.__wbg_get_ammodata_mag_offset(this.ptr);
        return ret;
    }
    /**
    * @param {number} arg0
    */
    set ads_time(arg0) {
        wasm.__wbg_set_ammodata_mag_offset(this.ptr, arg0);
    }
}

export class JsAmmoFormula {

    __destroy_into_raw() {
        const ptr = this.ptr;
        this.ptr = 0;

        return ptr;
    }

    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_jsammoformula_free(ptr);
    }
    /**
    */
    constructor() {
        const ret = wasm.jsammoformula_new();
        return AmmoData.__wrap(ret);
    }
}

export class JsAmmoResponse {

    __destroy_into_raw() {
        const ptr = this.ptr;
        this.ptr = 0;

        return ptr;
    }

    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_jsammoresponse_free(ptr);
    }
    /**
    * @returns {string}
    */
    toString() {
        try {
            const ptr = this.__destroy_into_raw();
            const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
            wasm.jsammoresponse_toString(retptr, ptr);
            var r0 = getInt32Memory0()[retptr / 4 + 0];
            var r1 = getInt32Memory0()[retptr / 4 + 1];
            return getStringFromWasm0(r0, r1);
        } finally {
            wasm.__wbindgen_add_to_stack_pointer(16);
            wasm.__wbindgen_free(r0, r1);
        }
    }
}

export class JsDamageModifiers {

    __destroy_into_raw() {
        const ptr = this.ptr;
        this.ptr = 0;

        return ptr;
    }

    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_jsdamagemodifiers_free(ptr);
    }
    /**
    */
    constructor() {
        const ret = wasm.jsdamagemodifiers_new();
        return DamageModifiers.__wrap(ret);
    }
}

export class JsDpsResponse {

    __destroy_into_raw() {
        const ptr = this.ptr;
        this.ptr = 0;

        return ptr;
    }

    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_jsdpsresponse_free(ptr);
    }
    /**
    * @returns {string}
    */
    toString() {
        try {
            const ptr = this.__destroy_into_raw();
            const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
            wasm.jsdpsresponse_toString(retptr, ptr);
            var r0 = getInt32Memory0()[retptr / 4 + 0];
            var r1 = getInt32Memory0()[retptr / 4 + 1];
            return getStringFromWasm0(r0, r1);
        } finally {
            wasm.__wbindgen_add_to_stack_pointer(16);
            wasm.__wbindgen_free(r0, r1);
        }
    }
    /**
    * @returns {(Float64Array)[]}
    */
    get time_damage_data() {
        try {
            const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
            wasm.jsdpsresponse_time_damage_data(retptr, this.ptr);
            var r0 = getInt32Memory0()[retptr / 4 + 0];
            var r1 = getInt32Memory0()[retptr / 4 + 1];
            var v0 = getArrayJsValueFromWasm0(r0, r1).slice();
            wasm.__wbindgen_free(r0, r1 * 4);
            return v0;
        } finally {
            wasm.__wbindgen_add_to_stack_pointer(16);
        }
    }
    /**
    * @returns {Float64Array}
    */
    get dps_per_mag() {
        try {
            const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
            wasm.jsdpsresponse_dps_per_mag(retptr, this.ptr);
            var r0 = getInt32Memory0()[retptr / 4 + 0];
            var r1 = getInt32Memory0()[retptr / 4 + 1];
            var v0 = getArrayF64FromWasm0(r0, r1).slice();
            wasm.__wbindgen_free(r0, r1 * 8);
            return v0;
        } finally {
            wasm.__wbindgen_add_to_stack_pointer(16);
        }
    }
}

export class JsFiringData {

    __destroy_into_raw() {
        const ptr = this.ptr;
        this.ptr = 0;

        return ptr;
    }

    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_jsfiringdata_free(ptr);
    }
    /**
    */
    constructor() {
        const ret = wasm.jsfiringdata_new();
        return FiringData.__wrap(ret);
    }
}

export class JsHandlingFormula {

    __destroy_into_raw() {
        const ptr = this.ptr;
        this.ptr = 0;

        return ptr;
    }

    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_jshandlingformula_free(ptr);
    }
    /**
    */
    constructor() {
        const ret = wasm.jshandlingformula_new();
        return HandlingFormula.__wrap(ret);
    }
}

export class JsHandlingResponse {

    __destroy_into_raw() {
        const ptr = this.ptr;
        this.ptr = 0;

        return ptr;
    }

    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_jshandlingresponse_free(ptr);
    }
    /**
    * @returns {string}
    */
    toString() {
        try {
            const ptr = this.__destroy_into_raw();
            const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
            wasm.jshandlingresponse_toString(retptr, ptr);
            var r0 = getInt32Memory0()[retptr / 4 + 0];
            var r1 = getInt32Memory0()[retptr / 4 + 1];
            return getStringFromWasm0(r0, r1);
        } finally {
            wasm.__wbindgen_add_to_stack_pointer(16);
            wasm.__wbindgen_free(r0, r1);
        }
    }
}

export class JsPerk {

    __destroy_into_raw() {
        const ptr = this.ptr;
        this.ptr = 0;

        return ptr;
    }

    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_jsperk_free(ptr);
    }
    /**
    */
    constructor() {
        const ret = wasm.jsperk_new();
        return Perk.__wrap(ret);
    }
    /**
    * @returns {(BigInt64Array)[]}
    */
    get stat_buffs() {
        try {
            const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
            wasm.jsperk_stat_buffs(retptr, this.ptr);
            var r0 = getInt32Memory0()[retptr / 4 + 0];
            var r1 = getInt32Memory0()[retptr / 4 + 1];
            var v0 = getArrayJsValueFromWasm0(r0, r1).slice();
            wasm.__wbindgen_free(r0, r1 * 4);
            return v0;
        } finally {
            wasm.__wbindgen_add_to_stack_pointer(16);
        }
    }
    /**
    * @param {(BigInt64Array)[]} stat_buffs
    */
    set stat_buffs(stat_buffs) {
        const ptr0 = passArrayJsValueToWasm0(stat_buffs, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        wasm.jsperk_set_stat_buffs(this.ptr, ptr0, len0);
    }
}

export class JsRangeFormula {

    __destroy_into_raw() {
        const ptr = this.ptr;
        this.ptr = 0;

        return ptr;
    }

    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_jsrangeformula_free(ptr);
    }
    /**
    */
    constructor() {
        const ret = wasm.jsrangeformula_new();
        return RangeFormula.__wrap(ret);
    }
}

export class JsRangeResponse {

    __destroy_into_raw() {
        const ptr = this.ptr;
        this.ptr = 0;

        return ptr;
    }

    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_jsrangeresponse_free(ptr);
    }
    /**
    * @returns {string}
    */
    toString() {
        try {
            const ptr = this.__destroy_into_raw();
            const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
            wasm.jsrangeresponse_toString(retptr, ptr);
            var r0 = getInt32Memory0()[retptr / 4 + 0];
            var r1 = getInt32Memory0()[retptr / 4 + 1];
            return getStringFromWasm0(r0, r1);
        } finally {
            wasm.__wbindgen_add_to_stack_pointer(16);
            wasm.__wbindgen_free(r0, r1);
        }
    }
}

export class JsReloadFormula {

    __destroy_into_raw() {
        const ptr = this.ptr;
        this.ptr = 0;

        return ptr;
    }

    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_jsreloadformula_free(ptr);
    }
    /**
    */
    constructor() {
        const ret = wasm.jsreloadformula_new();
        return ReloadFormula.__wrap(ret);
    }
}

export class JsReloadResponse {

    __destroy_into_raw() {
        const ptr = this.ptr;
        this.ptr = 0;

        return ptr;
    }

    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_jsreloadresponse_free(ptr);
    }
    /**
    * @returns {string}
    */
    toString() {
        try {
            const ptr = this.__destroy_into_raw();
            const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
            wasm.jsreloadresponse_toString(retptr, ptr);
            var r0 = getInt32Memory0()[retptr / 4 + 0];
            var r1 = getInt32Memory0()[retptr / 4 + 1];
            return getStringFromWasm0(r0, r1);
        } finally {
            wasm.__wbindgen_add_to_stack_pointer(16);
            wasm.__wbindgen_free(r0, r1);
        }
    }
}

export class JsStat {

    __destroy_into_raw() {
        const ptr = this.ptr;
        this.ptr = 0;

        return ptr;
    }

    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_jsstat_free(ptr);
    }
    /**
    * @returns {string}
    */
    toString() {
        try {
            const ptr = this.__destroy_into_raw();
            const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
            wasm.jsstat_toString(retptr, ptr);
            var r0 = getInt32Memory0()[retptr / 4 + 0];
            var r1 = getInt32Memory0()[retptr / 4 + 1];
            return getStringFromWasm0(r0, r1);
        } finally {
            wasm.__wbindgen_add_to_stack_pointer(16);
            wasm.__wbindgen_free(r0, r1);
        }
    }
}

export class JsTtkResponse {

    __destroy_into_raw() {
        const ptr = this.ptr;
        this.ptr = 0;

        return ptr;
    }

    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_jsttkresponse_free(ptr);
    }
    /**
    * @returns {string}
    */
    toString() {
        try {
            const ptr = this.__destroy_into_raw();
            const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
            wasm.jsttkresponse_toString(retptr, ptr);
            var r0 = getInt32Memory0()[retptr / 4 + 0];
            var r1 = getInt32Memory0()[retptr / 4 + 1];
            return getStringFromWasm0(r0, r1);
        } finally {
            wasm.__wbindgen_add_to_stack_pointer(16);
            wasm.__wbindgen_free(r0, r1);
        }
    }
}

export class JsWeapon {

    __destroy_into_raw() {
        const ptr = this.ptr;
        this.ptr = 0;

        return ptr;
    }

    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_jsweapon_free(ptr);
    }
    /**
    * @param {number} hash
    * @param {number} weapon_type
    * @param {number} damage_type
    * @param {number} weapon_slot
    * @param {number} ammo_type
    * @param {(BigInt64Array)[]} stats
    * @param {DamageModifiers} damage_modifiers
    * @param {WeaponFormula} formulas
    */
    constructor(hash, weapon_type, damage_type, weapon_slot, ammo_type, stats, damage_modifiers, formulas) {
        const ptr0 = passArrayJsValueToWasm0(stats, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        _assertClass(damage_modifiers, DamageModifiers);
        var ptr1 = damage_modifiers.ptr;
        damage_modifiers.ptr = 0;
        _assertClass(formulas, WeaponFormula);
        var ptr2 = formulas.ptr;
        formulas.ptr = 0;
        const ret = wasm.jsweapon_new(hash, weapon_type, damage_type, weapon_slot, ammo_type, ptr0, len0, ptr1, ptr2);
        return Weapon.__wrap(ret);
    }
    /**
    * @returns {(BigInt64Array)[]}
    */
    get stats() {
        try {
            const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
            wasm.jsweapon_stats(retptr, this.ptr);
            var r0 = getInt32Memory0()[retptr / 4 + 0];
            var r1 = getInt32Memory0()[retptr / 4 + 1];
            var v0 = getArrayJsValueFromWasm0(r0, r1).slice();
            wasm.__wbindgen_free(r0, r1 * 4);
            return v0;
        } finally {
            wasm.__wbindgen_add_to_stack_pointer(16);
        }
    }
    /**
    * @param {(BigInt64Array)[]} stats
    */
    set stats(stats) {
        const ptr0 = passArrayJsValueToWasm0(stats, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        wasm.jsweapon_set_stats(this.ptr, ptr0, len0);
    }
}

export class JsWeaponFormula {

    __destroy_into_raw() {
        const ptr = this.ptr;
        this.ptr = 0;

        return ptr;
    }

    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_jsweaponformula_free(ptr);
    }
    /**
    */
    constructor() {
        const ret = wasm.jsweaponformula_new();
        return WeaponFormula.__wrap(ret);
    }
}
/**
*/
export class Perk {

    static __wrap(ptr) {
        const obj = Object.create(Perk.prototype);
        obj.ptr = ptr;

        return obj;
    }

    __destroy_into_raw() {
        const ptr = this.ptr;
        this.ptr = 0;

        return ptr;
    }

    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_perk_free(ptr);
    }
    /**
    * @returns {boolean}
    */
    get enhanced() {
        const ret = wasm.__wbg_get_perk_enhanced(this.ptr);
        return ret !== 0;
    }
    /**
    * @param {boolean} arg0
    */
    set enhanced(arg0) {
        wasm.__wbg_set_perk_enhanced(this.ptr, arg0);
    }
    /**
    * @returns {number}
    */
    get value() {
        const ret = wasm.__wbg_get_perk_value(this.ptr);
        return ret;
    }
    /**
    * @param {number} arg0
    */
    set value(arg0) {
        wasm.__wbg_set_perk_value(this.ptr, arg0);
    }
    /**
    * @returns {number}
    */
    get id() {
        const ret = wasm.__wbg_get_perk_id(this.ptr);
        return ret >>> 0;
    }
    /**
    * @param {number} arg0
    */
    set id(arg0) {
        wasm.__wbg_set_perk_id(this.ptr, arg0);
    }
}
/**
*/
export class RangeFormula {

    static __wrap(ptr) {
        const obj = Object.create(RangeFormula.prototype);
        obj.ptr = ptr;

        return obj;
    }

    __destroy_into_raw() {
        const ptr = this.ptr;
        this.ptr = 0;

        return ptr;
    }

    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_rangeformula_free(ptr);
    }
    /**
    * @returns {number}
    */
    get vpp_start() {
        const ret = wasm.__wbg_get_ammodata_mag_evpp(this.ptr);
        return ret;
    }
    /**
    * @param {number} arg0
    */
    set vpp_start(arg0) {
        wasm.__wbg_set_ammodata_mag_evpp(this.ptr, arg0);
    }
    /**
    * @returns {number}
    */
    get offset_start() {
        const ret = wasm.__wbg_get_ammodata_mag_vpp(this.ptr);
        return ret;
    }
    /**
    * @param {number} arg0
    */
    set offset_start(arg0) {
        wasm.__wbg_set_ammodata_mag_vpp(this.ptr, arg0);
    }
    /**
    * @returns {number}
    */
    get vpp_end() {
        const ret = wasm.__wbg_get_ammodata_mag_offset(this.ptr);
        return ret;
    }
    /**
    * @param {number} arg0
    */
    set vpp_end(arg0) {
        wasm.__wbg_set_ammodata_mag_offset(this.ptr, arg0);
    }
    /**
    * @returns {number}
    */
    get offset_end() {
        const ret = wasm.__wbg_get_damagemodifiers_miniboss(this.ptr);
        return ret;
    }
    /**
    * @param {number} arg0
    */
    set offset_end(arg0) {
        wasm.__wbg_set_damagemodifiers_miniboss(this.ptr, arg0);
    }
    /**
    * @returns {number}
    */
    get floor_percent() {
        const ret = wasm.__wbg_get_damagemodifiers_champion(this.ptr);
        return ret;
    }
    /**
    * @param {number} arg0
    */
    set floor_percent(arg0) {
        wasm.__wbg_set_damagemodifiers_champion(this.ptr, arg0);
    }
    /**
    * @returns {boolean}
    */
    get is_fusion() {
        const ret = wasm.__wbg_get_rangeformula_is_fusion(this.ptr);
        return ret !== 0;
    }
    /**
    * @param {boolean} arg0
    */
    set is_fusion(arg0) {
        wasm.__wbg_set_rangeformula_is_fusion(this.ptr, arg0);
    }
}
/**
*/
export class RangeResponse {

    __destroy_into_raw() {
        const ptr = this.ptr;
        this.ptr = 0;

        return ptr;
    }

    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_rangeresponse_free(ptr);
    }
    /**
    * @returns {number}
    */
    get hip_falloff_start() {
        const ret = wasm.__wbg_get_ammodata_mag_evpp(this.ptr);
        return ret;
    }
    /**
    * @param {number} arg0
    */
    set hip_falloff_start(arg0) {
        wasm.__wbg_set_ammodata_mag_evpp(this.ptr, arg0);
    }
    /**
    * @returns {number}
    */
    get hip_falloff_end() {
        const ret = wasm.__wbg_get_ammodata_mag_vpp(this.ptr);
        return ret;
    }
    /**
    * @param {number} arg0
    */
    set hip_falloff_end(arg0) {
        wasm.__wbg_set_ammodata_mag_vpp(this.ptr, arg0);
    }
    /**
    * @returns {number}
    */
    get ads_falloff_start() {
        const ret = wasm.__wbg_get_ammodata_mag_offset(this.ptr);
        return ret;
    }
    /**
    * @param {number} arg0
    */
    set ads_falloff_start(arg0) {
        wasm.__wbg_set_ammodata_mag_offset(this.ptr, arg0);
    }
    /**
    * @returns {number}
    */
    get ads_falloff_end() {
        const ret = wasm.__wbg_get_damagemodifiers_miniboss(this.ptr);
        return ret;
    }
    /**
    * @param {number} arg0
    */
    set ads_falloff_end(arg0) {
        wasm.__wbg_set_damagemodifiers_miniboss(this.ptr, arg0);
    }
    /**
    * @returns {number}
    */
    get floor_percent() {
        const ret = wasm.__wbg_get_damagemodifiers_champion(this.ptr);
        return ret;
    }
    /**
    * @param {number} arg0
    */
    set floor_percent(arg0) {
        wasm.__wbg_set_damagemodifiers_champion(this.ptr, arg0);
    }
}
/**
*/
export class ReloadFormula {

    static __wrap(ptr) {
        const obj = Object.create(ReloadFormula.prototype);
        obj.ptr = ptr;

        return obj;
    }

    __destroy_into_raw() {
        const ptr = this.ptr;
        this.ptr = 0;

        return ptr;
    }

    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_reloadformula_free(ptr);
    }
    /**
    * @returns {number}
    */
    get evpp() {
        const ret = wasm.__wbg_get_ammodata_mag_evpp(this.ptr);
        return ret;
    }
    /**
    * @param {number} arg0
    */
    set evpp(arg0) {
        wasm.__wbg_set_ammodata_mag_evpp(this.ptr, arg0);
    }
    /**
    * @returns {number}
    */
    get vpp() {
        const ret = wasm.__wbg_get_ammodata_mag_vpp(this.ptr);
        return ret;
    }
    /**
    * @param {number} arg0
    */
    set vpp(arg0) {
        wasm.__wbg_set_ammodata_mag_vpp(this.ptr, arg0);
    }
    /**
    * @returns {number}
    */
    get offset() {
        const ret = wasm.__wbg_get_ammodata_mag_offset(this.ptr);
        return ret;
    }
    /**
    * @param {number} arg0
    */
    set offset(arg0) {
        wasm.__wbg_set_ammodata_mag_offset(this.ptr, arg0);
    }
    /**
    * @returns {number}
    */
    get ammo_percent() {
        const ret = wasm.__wbg_get_damagemodifiers_miniboss(this.ptr);
        return ret;
    }
    /**
    * @param {number} arg0
    */
    set ammo_percent(arg0) {
        wasm.__wbg_set_damagemodifiers_miniboss(this.ptr, arg0);
    }
}
/**
*/
export class ReloadResponse {

    __destroy_into_raw() {
        const ptr = this.ptr;
        this.ptr = 0;

        return ptr;
    }

    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_reloadresponse_free(ptr);
    }
    /**
    * @returns {number}
    */
    get reload_time() {
        const ret = wasm.__wbg_get_ammodata_mag_evpp(this.ptr);
        return ret;
    }
    /**
    * @param {number} arg0
    */
    set reload_time(arg0) {
        wasm.__wbg_set_ammodata_mag_evpp(this.ptr, arg0);
    }
    /**
    * @returns {number}
    */
    get ammo_time() {
        const ret = wasm.__wbg_get_ammodata_mag_vpp(this.ptr);
        return ret;
    }
    /**
    * @param {number} arg0
    */
    set ammo_time(arg0) {
        wasm.__wbg_set_ammodata_mag_vpp(this.ptr, arg0);
    }
}
/**
*/
export class Stat {

    static __wrap(ptr) {
        const obj = Object.create(Stat.prototype);
        obj.ptr = ptr;

        return obj;
    }

    __destroy_into_raw() {
        const ptr = this.ptr;
        this.ptr = 0;

        return ptr;
    }

    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_stat_free(ptr);
    }
    /**
    * @returns {number}
    */
    get base_value() {
        const ret = wasm.__wbg_get_ammoresponse_mag_size(this.ptr);
        return ret;
    }
    /**
    * @param {number} arg0
    */
    set base_value(arg0) {
        wasm.__wbg_set_ammoresponse_mag_size(this.ptr, arg0);
    }
    /**
    * @returns {number}
    */
    get part_value() {
        const ret = wasm.__wbg_get_ammoresponse_reserve_size(this.ptr);
        return ret;
    }
    /**
    * @param {number} arg0
    */
    set part_value(arg0) {
        wasm.__wbg_set_ammoresponse_reserve_size(this.ptr, arg0);
    }
    /**
    * @returns {number}
    */
    get perk_value() {
        const ret = wasm.__wbg_get_stat_perk_value(this.ptr);
        return ret;
    }
    /**
    * @param {number} arg0
    */
    set perk_value(arg0) {
        wasm.__wbg_set_stat_perk_value(this.ptr, arg0);
    }
}
/**
*/
export class TtkResponse {

    __destroy_into_raw() {
        const ptr = this.ptr;
        this.ptr = 0;

        return ptr;
    }

    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_ttkresponse_free(ptr);
    }
    /**
    * @returns {number}
    */
    get ammo_needed() {
        const ret = wasm.__wbg_get_ammodata_mag_round_to_nearest(this.ptr);
        return ret;
    }
    /**
    * @param {number} arg0
    */
    set ammo_needed(arg0) {
        wasm.__wbg_set_ammodata_mag_round_to_nearest(this.ptr, arg0);
    }
    /**
    * @returns {number}
    */
    get hits_needed() {
        const ret = wasm.__wbg_get_ammodata_reserve_id(this.ptr);
        return ret;
    }
    /**
    * @param {number} arg0
    */
    set hits_needed(arg0) {
        wasm.__wbg_set_ammodata_reserve_id(this.ptr, arg0);
    }
    /**
    * @returns {number}
    */
    get optimal_ttk() {
        const ret = wasm.__wbg_get_ammodata_mag_evpp(this.ptr);
        return ret;
    }
    /**
    * @param {number} arg0
    */
    set optimal_ttk(arg0) {
        wasm.__wbg_set_ammodata_mag_evpp(this.ptr, arg0);
    }
    /**
    * @returns {number}
    */
    get crit_percent() {
        const ret = wasm.__wbg_get_ammodata_mag_vpp(this.ptr);
        return ret;
    }
    /**
    * @param {number} arg0
    */
    set crit_percent(arg0) {
        wasm.__wbg_set_ammodata_mag_vpp(this.ptr, arg0);
    }
    /**
    * @returns {number}
    */
    get bodyshot_ttk() {
        const ret = wasm.__wbg_get_ammodata_mag_offset(this.ptr);
        return ret;
    }
    /**
    * @param {number} arg0
    */
    set bodyshot_ttk(arg0) {
        wasm.__wbg_set_ammodata_mag_offset(this.ptr, arg0);
    }
}
/**
*/
export class Weapon {

    static __wrap(ptr) {
        const obj = Object.create(Weapon.prototype);
        obj.ptr = ptr;

        return obj;
    }

    __destroy_into_raw() {
        const ptr = this.ptr;
        this.ptr = 0;

        return ptr;
    }

    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_weapon_free(ptr);
    }
    /**
    * @returns {number}
    */
    get hash() {
        const ret = wasm.__wbg_get_weapon_hash(this.ptr);
        return ret >>> 0;
    }
    /**
    * @param {number} arg0
    */
    set hash(arg0) {
        wasm.__wbg_set_weapon_hash(this.ptr, arg0);
    }
    /**
    * @returns {number}
    */
    get weapon_type() {
        const ret = wasm.__wbg_get_weapon_weapon_type(this.ptr);
        return ret >>> 0;
    }
    /**
    * @param {number} arg0
    */
    set weapon_type(arg0) {
        wasm.__wbg_set_weapon_weapon_type(this.ptr, arg0);
    }
    /**
    * @returns {number}
    */
    get damage_type() {
        const ret = wasm.__wbg_get_weapon_damage_type(this.ptr);
        return ret >>> 0;
    }
    /**
    * @param {number} arg0
    */
    set damage_type(arg0) {
        wasm.__wbg_set_weapon_damage_type(this.ptr, arg0);
    }
    /**
    * @returns {number}
    */
    get weapon_slot() {
        const ret = wasm.__wbg_get_weapon_weapon_slot(this.ptr);
        return ret >>> 0;
    }
    /**
    * @param {number} arg0
    */
    set weapon_slot(arg0) {
        wasm.__wbg_set_weapon_weapon_slot(this.ptr, arg0);
    }
    /**
    * @returns {number}
    */
    get ammo_type() {
        const ret = wasm.__wbg_get_weapon_ammo_type(this.ptr);
        return ret >>> 0;
    }
    /**
    * @param {number} arg0
    */
    set ammo_type(arg0) {
        wasm.__wbg_set_weapon_ammo_type(this.ptr, arg0);
    }
    /**
    * @returns {DamageModifiers}
    */
    get damage_modifiers() {
        const ret = wasm.__wbg_get_weapon_damage_modifiers(this.ptr);
        return DamageModifiers.__wrap(ret);
    }
    /**
    * @param {DamageModifiers} arg0
    */
    set damage_modifiers(arg0) {
        _assertClass(arg0, DamageModifiers);
        var ptr0 = arg0.ptr;
        arg0.ptr = 0;
        wasm.__wbg_set_weapon_damage_modifiers(this.ptr, ptr0);
    }
    /**
    * @returns {WeaponFormula}
    */
    get formulas() {
        const ret = wasm.__wbg_get_weapon_formulas(this.ptr);
        return WeaponFormula.__wrap(ret);
    }
    /**
    * @param {WeaponFormula} arg0
    */
    set formulas(arg0) {
        _assertClass(arg0, WeaponFormula);
        var ptr0 = arg0.ptr;
        arg0.ptr = 0;
        wasm.__wbg_set_weapon_formulas(this.ptr, ptr0);
    }
}
/**
*/
export class WeaponFormula {

    static __wrap(ptr) {
        const obj = Object.create(WeaponFormula.prototype);
        obj.ptr = ptr;

        return obj;
    }

    __destroy_into_raw() {
        const ptr = this.ptr;
        this.ptr = 0;

        return ptr;
    }

    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_weaponformula_free(ptr);
    }
    /**
    * @returns {RangeFormula}
    */
    get range_data() {
        const ret = wasm.__wbg_get_weaponformula_range_data(this.ptr);
        return RangeFormula.__wrap(ret);
    }
    /**
    * @param {RangeFormula} arg0
    */
    set range_data(arg0) {
        _assertClass(arg0, RangeFormula);
        var ptr0 = arg0.ptr;
        arg0.ptr = 0;
        wasm.__wbg_set_weaponformula_range_data(this.ptr, ptr0);
    }
    /**
    * @returns {ReloadFormula}
    */
    get reload_data() {
        const ret = wasm.__wbg_get_weaponformula_reload_data(this.ptr);
        return ReloadFormula.__wrap(ret);
    }
    /**
    * @param {ReloadFormula} arg0
    */
    set reload_data(arg0) {
        _assertClass(arg0, ReloadFormula);
        var ptr0 = arg0.ptr;
        arg0.ptr = 0;
        wasm.__wbg_set_weaponformula_reload_data(this.ptr, ptr0);
    }
    /**
    * @returns {HandlingFormula}
    */
    get handling_data() {
        const ret = wasm.__wbg_get_weaponformula_handling_data(this.ptr);
        return HandlingFormula.__wrap(ret);
    }
    /**
    * @param {HandlingFormula} arg0
    */
    set handling_data(arg0) {
        _assertClass(arg0, HandlingFormula);
        var ptr0 = arg0.ptr;
        arg0.ptr = 0;
        wasm.__wbg_set_weaponformula_handling_data(this.ptr, ptr0);
    }
    /**
    * @returns {FiringData}
    */
    get firing_data() {
        const ret = wasm.__wbg_get_weaponformula_firing_data(this.ptr);
        return FiringData.__wrap(ret);
    }
    /**
    * @param {FiringData} arg0
    */
    set firing_data(arg0) {
        _assertClass(arg0, FiringData);
        var ptr0 = arg0.ptr;
        arg0.ptr = 0;
        wasm.__wbg_set_weaponformula_firing_data(this.ptr, ptr0);
    }
    /**
    * @returns {AmmoData}
    */
    get ammo_data() {
        const ret = wasm.__wbg_get_weaponformula_ammo_data(this.ptr);
        return AmmoData.__wrap(ret);
    }
    /**
    * @param {AmmoData} arg0
    */
    set ammo_data(arg0) {
        _assertClass(arg0, AmmoData);
        var ptr0 = arg0.ptr;
        arg0.ptr = 0;
        wasm.__wbg_set_weaponformula_ammo_data(this.ptr, ptr0);
    }
}

export function __wbindgen_object_drop_ref(arg0) {
    takeObject(arg0);
};

export function __wbindgen_object_clone_ref(arg0) {
    const ret = getObject(arg0);
    return addHeapObject(ret);
};

export function __wbg_log_9aa4b56d911aee04(arg0, arg1) {
    console.log(getStringFromWasm0(arg0, arg1));
};

export function __wbg_new_abda76e883ba8a5f() {
    const ret = new Error();
    return addHeapObject(ret);
};

export function __wbg_stack_658279fe44541cf6(arg0, arg1) {
    const ret = getObject(arg1).stack;
    const ptr0 = passStringToWasm0(ret, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    const len0 = WASM_VECTOR_LEN;
    getInt32Memory0()[arg0 / 4 + 1] = len0;
    getInt32Memory0()[arg0 / 4 + 0] = ptr0;
};

export function __wbg_error_f851667af71bcfc6(arg0, arg1) {
    try {
        console.error(getStringFromWasm0(arg0, arg1));
    } finally {
        wasm.__wbindgen_free(arg0, arg1);
    }
};

export function __wbg_newwithlength_cd2aafd92be9b99d(arg0) {
    const ret = new BigInt64Array(arg0 >>> 0);
    return addHeapObject(ret);
};

export function __wbg_getindex_a8f29f7f45baf28b(arg0, arg1) {
    const ret = getObject(arg0)[arg1 >>> 0];
    return ret;
};

export function __wbg_setindex_2b5fe32a1ccf8952(arg0, arg1, arg2) {
    getObject(arg0)[arg1 >>> 0] = arg2;
};

export function __wbindgen_debug_string(arg0, arg1) {
    const ret = debugString(getObject(arg1));
    const ptr0 = passStringToWasm0(ret, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    const len0 = WASM_VECTOR_LEN;
    getInt32Memory0()[arg0 / 4 + 1] = len0;
    getInt32Memory0()[arg0 / 4 + 0] = ptr0;
};

export function __wbindgen_throw(arg0, arg1) {
    throw new Error(getStringFromWasm0(arg0, arg1));
};

